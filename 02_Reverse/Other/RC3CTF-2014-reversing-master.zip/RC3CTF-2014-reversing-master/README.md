RC3 CTF Challenges
==================
Here are the five reversing challenges designed for the first annual RC3 CTF to be hosted 11/22/2014.

Overview and points:

<b>chal1</b> - 20 points - Simple strings exercise

<b>chal2</b> - 40 points - Divide by zero

<b>chal3</b> - 80 points - Stack overflow to overwite variables

<b>chal4</b> - 100 points - Anti-reversing techniques

<b>chal5</b> - 60 points - Global variable search

