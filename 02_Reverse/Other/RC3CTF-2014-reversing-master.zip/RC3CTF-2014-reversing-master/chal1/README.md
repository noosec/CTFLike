Challenge 1 - 20 Points
========================
An old CS project.

Hint
----
1. Filter output

Solution
--------
Just run strings on it and do bit of searching to get the flag.

OR

strings chal2 | grep RC3
