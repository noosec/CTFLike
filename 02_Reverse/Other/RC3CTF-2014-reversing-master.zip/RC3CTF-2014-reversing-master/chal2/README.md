Challenge 2 - 40 Points
========================
Relies on the SIGFPE handler. Nearly identical to the stackoverflow challenge. Still fun though.

**Must be run on a 32-bit system!**

Hint
----
1. Just do what you are never supposed to

Solution
--------
Divide by zero or enter a really big negative number and -1
