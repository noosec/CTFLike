Challenge 4 - 100 Points
========================
There are measures in place to prevent debugging. Break them and get the flag.

Hints
-----
1. Check out the functions in this executable

2. GDB can be used to set registers

Solution
--------
Jump over anti_debug in main and in the thread to get the flag.
