
#include <stdio.h>

void main(void) {
    if (false) {
        printf("OK");
        return;
    }
    printf("No");
}
