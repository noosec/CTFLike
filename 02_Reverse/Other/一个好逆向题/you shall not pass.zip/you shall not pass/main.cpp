#include <iostream>
#include <string>
#include <cstdlib>
#include "base64.h"
#include "MD5.h"

using namespace std;

bool func_check1(string str1, string str2, int check2[])
{
	int len = str1.length();

	__asm jz Do_It3
	__asm jnz Do_It3
	__asm 
	{
		__emit 099h
		__emit 098h
		__emit 097h
	}
Do_It3: 
	__asm jz Do_It4
	__asm jnz Do_It4
	__asm 
	{
		__emit 096h
		__emit 094h
		__emit 092h
		__emit 091h
		__emit 090h
		__emit 089h
	}
Do_It4: 


	for (int i=0; i<=len-1; i++)
	{
		if (str1[i] - str2[i] != check2[i])
		{
			return false;
		}
	}

	return true;
}

bool func_check2(char *input)
{
	char check[] = "MzR0";

	__asm jz Do_It3
	__asm jnz Do_It3
	__asm  __emit 0e3h
	Do_It3: 

	if (strcmp(base64_encode(input, 3), check) == 0) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

int main()
{
	//TSCTF{YQ_w4nts_t0_34t_L4T140}
	//29
	//char flag[] = "TSCTF{YQ_w4nts_T0_34t_LTlt17}";
	//cout << strlen(flag) << endl;
	cout << "Give me the flag! I want the flag!" << endl << "Flag:";

	char input[128];
	cin.getline(input, 127);

	int len = strlen(input);
	if (len >= 30 || len<=0)
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	/////////////////////////////��ָ��/////////////////////////////
	__asm
	{
		jz CHUNK_CODE
		jnz CHUNK_CODE
		//0x6b 0x61 0x6e 0x7a 0x68 0x65 0x6c 0x69 
		__emit 06bh
		__emit 061h
		__emit 06eh
		__emit 07ah
		__emit 068h
		__emit 065h
		__emit 06ch
		__emit 069h
	}
CHUNK_CODE:


	char flag1[] = "TSCTF{";
	int len2 = strlen(flag1);

	for (int i=0; i<=len2-1; i++)
	{
		if (flag1[i] != input[i])
		{
			cout << "You shall not pass!" << endl;
			return -1;
		}
	}

	if (input[28] != '}')
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	if (input[8]!='_' || input[14]!='_' || input[17]!='_' || input[21]!='_')
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	__asm
	{
		jz CHUNK_CODE2
		jnz CHUNK_CODE3
		//0x54 0x53 0x43 0x54 0x46 0x7b 0x7d 
		__emit 054h
		__emit 053h
		__emit 043h
		__emit 054h
		__emit 046h
		__emit 07bh
		__emit 07dh
	}
CHUNK_CODE2:
	__asm
	{
		jz CHUNK_CODE3
		jnz CHUNK_CODE3
		//0x55 0x73 0x65 0x6c 0x65 0x73 0x73 
		__emit 055h
		__emit 073h
		__emit 065h
		__emit 06ch
		__emit 065h
		__emit 073h
		__emit 073h
	}
CHUNK_CODE3:


	MD5 md5;
	unsigned char a[3] = "AA";
	a[0] = input[6];
	a[1] = input[7];
	md5.GenerateMD5(a, 2);

	string check_str1 = "dcfed125d6507dc8c473c49fd8ad891d";
	if (check_str1 != md5.ToString())
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}
	//string check_str2 = "cda99cf90480d165fdd7119d76ce6aa6";
	int check2[] = {-1, 1, -5, -44, -43, 50, 52, 4, -52, -2, 3, 0, 45, -51, -45, -3, 
					3, 48, 45, 4, -50, -3, 0, -2, -45, -2, 2, 1, -2, 40, 48, -46};

	unsigned char b[6] = "AAAAA";
	b[0] = input[9];
	b[1] = input[10];
	b[2] = input[11];
	b[3] = input[12];
	b[4] = input[13];
	MD5 md52;
	md52.GenerateMD5(b, 5);
	string check_str2  = md52.ToString();

	if (!func_check1(check_str2, check_str1, check2))
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	char c[4];
	c[0] = input[18];
	c[1] = input[19];
	c[2] = input[20];
	c[3] = '\0';
	if (!func_check2(c))
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	FILE *file = fopen("xor", "rb");
	FILE *out = fopen("xorxor.bmp", "wb");

	if (file==NULL || out==NULL)
	{
		cout << "You shall not pass!" << endl;
		return -1;
	}

	i = 0;
	char cc = fgetc(file);

	__asm jz Do_It
	__asm jnz Do_It
	__asm  __emit 0e8h
	Do_It: 


	while (!feof(file))
	{
		if (i==0)
		{
			fprintf(out, "%c", cc ^ input[15]);
		}
		else
		{
			fprintf(out, "%c", cc ^ input[16]);
			i = -1;
		}

		cc = fgetc(file);
		i++;
	}

	fclose(file);
	fclose(out);

	__asm jz Do_It2
	__asm jnz Do_It2
	__asm  __emit 0e8h
	Do_It2: 


	MD5 md5_all;
	md5.GenerateMD5((unsigned char*)input, 29);
	if (md5.ToString() == "f8c1c3fe8421451965fc3487ed2366e8")
	{
		cout << "You shall get the flag!" << endl;
	}
	else
	{
		cout << "You shall not pass!" << endl;
	}

	system("pause");
	return 0;
}